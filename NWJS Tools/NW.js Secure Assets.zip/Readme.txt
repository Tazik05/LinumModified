|---------------------------------------------------------------|
| Batch written by TheRealDannyyy! (Made for the C2 Community.) |
|---------------------------------------------------------------|

------------------|
What is this for? |
------------------|
This batch will help you to merge your nw.exe file(s) 
with the equal package.nw file(s), so that it is hidden for the end-user.

------------------|
How does it work? |
------------------|
It's a simple batch script, nothing special to be honest.
I've added some additional file checks so that nothing can go wrong.

----------------------------|
How can I make use of this? |
----------------------------|
Just put it inside your exported win32/win64 NW.js folder(s) and run it once.
It will even show you the progress and other useful information!

-----------------------|
Shameless Promotion... |
-----------------------|
NW.js Help (C2 Forum) = https://www.scirra.com/forum/updated-02-12-2016-the-big-nw-js-roundup-tips-amp-tricks_t184449
Discord Server = https://discord.gg/0eLPLj96B4tUr1D3